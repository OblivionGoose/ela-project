extends Area2D

@export var item: ItemData
@export var quantity: int = 1

func _ready():
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		var success = GameManager.player_inventory.add_item(item, quantity)
		if success:
			# Refresh inventory UI if it's open
			var world = get_tree().get_nodes_in_group("world2d")
			if world.size() > 0:
				var canvas = world[0].get_node_or_null("CanvasLayer")
				if canvas:
					var inv_ui = canvas.get_node_or_null("InventoryUI")
					if inv_ui and inv_ui.visible:
						inv_ui.refresh()
			queue_free()
